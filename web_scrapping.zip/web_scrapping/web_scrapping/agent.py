import json
import os
import re
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
from rapidfuzz import fuzz


REAL_ESTATE_SITES = [
	{"name": "Zillow", "domain": "zillow.com"},
	{"name": "Redfin", "domain": "redfin.com"},
	{"name": "Realtor", "domain": "realtor.com"},
	{"name": "Trulia", "domain": "trulia.com"},
	{"name": "Movoto", "domain": "movoto.com"},
	{"name": "REMAX", "domain": "remax.com"},
	{"name": "Homesnap", "domain": "homesnap.com"},
]

HEADERS = {
	"User-Agent": (
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
		"(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
	),
	"Accept-Language": "en-US,en;q=0.9",
}


@dataclass
class Address:
	street: Optional[str] = None
	city: Optional[str] = None
	state: Optional[str] = None
	postal_code: Optional[str] = None


@dataclass
class PropertyDetails:
	address: Address
	price: Optional[str] = None
	bedrooms: Optional[str] = None
	bathrooms: Optional[str] = None
	sqft: Optional[str] = None
	lot_size: Optional[str] = None
	year_built: Optional[str] = None
	property_type: Optional[str] = None
	last_sold_date: Optional[str] = None
	last_sold_price: Optional[str] = None
	source: Optional[str] = None
	source_url: Optional[str] = None


def normalize_whitespace(text: Optional[str]) -> Optional[str]:
	if text is None:
		return None
	return re.sub(r"\s+", " ", text).strip()


def normalize_address_for_match(text: str) -> str:
	text = text.lower()
	text = re.sub(r"[^a-z0-9 ]", " ", text)
	text = re.sub(r"\s+", " ", text).strip()
	return text


def fuzzy_address_score(a: str, b: str) -> int:
	return max(
		fuzz.token_set_ratio(a, b),
		fuzz.partial_ratio(a, b),
	)


def ddg_search(query: str, max_results: int = 6) -> List[Dict[str, str]]:
	with DDGS() as ddgs:
		return list(ddgs.text(query, region="us-en", max_results=max_results))


def pick_best_result(results: List[Dict[str, str]], address_query: str, domain: str) -> Optional[str]:
	address_norm = normalize_address_for_match(address_query)
	best_url: Optional[str] = None
	best_score = -1
	for r in results:
		url = r.get("href") or r.get("link") or r.get("url")
		if not url or domain not in url:
			continue
		title = r.get("title") or ""
		desc = r.get("body") or r.get("snippet") or ""
		combined = f"{title} {desc} {url}"
		score = fuzzy_address_score(address_norm, normalize_address_for_match(combined))
		if score > best_score:
			best_score = score
			best_url = url
	return best_url


def http_get(url: str, timeout: int = 20) -> Optional[str]:
	try:
		resp = requests.get(url, headers=HEADERS, timeout=timeout)
		if resp.status_code == 200:
			return resp.text
		return None
	except requests.RequestException:
		return None


def extract_json_ld(soup: BeautifulSoup) -> List[dict]:
	data = []
	for tag in soup.find_all("script", type="application/ld+json"):
		try:
			text = tag.get_text(strip=True)
			if not text:
				continue
			parsed = json.loads(text)
			if isinstance(parsed, list):
				data.extend(parsed)
			else:
				data.append(parsed)
		except Exception:
			continue
	return data


def extract_address_from_ld(ld: dict) -> Address:
	addr = ld.get("address") or {}
	if isinstance(addr, list) and addr:
		addr = addr[0]
	return Address(
		street=normalize_whitespace(addr.get("streetAddress")) if isinstance(addr, dict) else None,
		city=normalize_whitespace(addr.get("addressLocality")) if isinstance(addr, dict) else None,
		state=normalize_whitespace(addr.get("addressRegion")) if isinstance(addr, dict) else None,
		postal_code=normalize_whitespace(addr.get("postalCode")) if isinstance(addr, dict) else None,
	)


def extract_property_from_ld(ld: dict) -> PropertyDetails:
	address = extract_address_from_ld(ld)
	price = None
	if isinstance(ld.get("offers"), dict):
		price = ld["offers"].get("price") or ld["offers"].get("lowPrice")
	return PropertyDetails(
		address=address,
		price=normalize_whitespace(str(price)) if price is not None else None,
		bedrooms=normalize_whitespace(str(ld.get("numberOfRooms") or ld.get("bedrooms"))) if (ld.get("numberOfRooms") or ld.get("bedrooms")) else None,
		bathrooms=normalize_whitespace(str(ld.get("numberOfBathroomsTotal") or ld.get("bathrooms"))) if (ld.get("numberOfBathroomsTotal") or ld.get("bathrooms")) else None,
		sqft=normalize_whitespace(str(ld.get("floorSize", {}).get("value"))) if isinstance(ld.get("floorSize"), dict) else None,
		lot_size=normalize_whitespace(str(ld.get("lotSize", {}).get("value"))) if isinstance(ld.get("lotSize"), dict) else None,
		year_built=normalize_whitespace(str(ld.get("yearBuilt"))) if ld.get("yearBuilt") else None,
		property_type=normalize_whitespace(ld.get("@type")) if ld.get("@type") else None,
		last_sold_date=None,
		last_sold_price=None,
	)


def extract_fallback_fields(soup: BeautifulSoup) -> Dict[str, Optional[str]]:
	text = soup.get_text(" ", strip=True)
	def find(pattern: str) -> Optional[str]:
		m = re.search(pattern, text, flags=re.IGNORECASE)
		return m.group(1).strip() if m else None

	price = find(r"\$[0-9,.]+")
	year_built = find(r"Year Built[:\s]+(\d{4})")
	sqft = find(r"([0-9,.]+)\s*(sq\.?\s*ft|square\s*feet)")
	beds = find(r"(\d+(?:\.\d+)?)\s*beds?")
	baths = find(r"(\d+(?:\.\d+)?)\s*baths?")
	return {
		"price": price,
		"year_built": year_built,
		"sqft": sqft,
		"bedrooms": beds,
		"bathrooms": baths,
	}


def extract_details_from_url(source_name: str, url: str) -> Optional[PropertyDetails]:
	html = http_get(url)
	if not html:
		return None
	soup = BeautifulSoup(html, "lxml")
	ld_blocks = extract_json_ld(soup)
	candidate: Optional[PropertyDetails] = None
	for ld in ld_blocks:
		try:
			if isinstance(ld, dict) and ld.get("@type") in {"Residence", "House", "SingleFamilyResidence", "Apartment", "RealEstateListing", "Place"}:
				pd = extract_property_from_ld(ld)
				candidate = pd
				break
		except Exception:
			continue
	if candidate is None:
		candidate = PropertyDetails(address=Address())

	fallback = extract_fallback_fields(soup)
	if not candidate.price and fallback.get("price"):
		candidate.price = fallback["price"]
	if not candidate.year_built and fallback.get("year_built"):
		candidate.year_built = fallback["year_built"]
	if not candidate.sqft and fallback.get("sqft"):
		candidate.sqft = fallback["sqft"]
	if not candidate.bedrooms and fallback.get("bedrooms"):
		candidate.bedrooms = fallback["bedrooms"]
	if not candidate.bathrooms and fallback.get("bathrooms"):
		candidate.bathrooms = fallback["bathrooms"]

	candidate.source = source_name
	candidate.source_url = url
	return candidate


def search_and_scrape_for_site(site: Dict[str, str], address_line: str, city: str, state_zip: str) -> Optional[PropertyDetails]:
	domain = site["domain"]
	site_name = site["name"]
	query = f"site:{domain} {address_line} {city} {state_zip}"
	results = ddg_search(query, max_results=8)
	best_url = pick_best_result(results, f"{address_line} {city} {state_zip}", domain)
	if not best_url:
		return None
	return extract_details_from_url(site_name, best_url)


def consolidate(values: List[Optional[str]]) -> Optional[str]:
	filtered = [normalize_whitespace(v) for v in values if v]
	if not filtered:
		return None
	# Majority vote by normalized text
	counts: Dict[str, int] = {}
	for v in filtered:
		counts[v] = counts.get(v, 0) + 1
	sorted_items = sorted(counts.items(), key=lambda x: (-x[1], -len(x[0])))
	return sorted_items[0][0]


def consolidate_address(addresses: List[Address]) -> Address:
	return Address(
		street=consolidate([a.street for a in addresses]),
		city=consolidate([a.city for a in addresses]),
		state=consolidate([a.state for a in addresses]),
		postal_code=consolidate([a.postal_code for a in addresses]),
	)


def verify_against_input(addr: Address, address_line: str, city: str, state_zip: str) -> Dict[str, Dict[str, Optional[str]]]:
	input_norm = normalize_address_for_match(f"{address_line} {city} {state_zip}")
	cand_norm = normalize_address_for_match(" ".join(
		[x for x in [addr.street, addr.city, addr.state, addr.postal_code] if x]
	))
	score = fuzzy_address_score(input_norm, cand_norm)
	return {
		"address_match": {
			"score": score,
			"is_strong_match": bool(score >= 85),
		},
	}


def run_property_agent(address_line: str, city: str, state_zip: str, output_dir: str = "output") -> Dict:
	os.makedirs(output_dir, exist_ok=True)
	per_source: List[PropertyDetails] = []

	for site in REAL_ESTATE_SITES:
		try:
			pd = search_and_scrape_for_site(site, address_line, city, state_zip)
			if pd:
				per_source.append(pd)
				# be polite with a small delay to avoid hammering
				time.sleep(1.0)
		except Exception:
			continue

	consolidated = {
		"address": asdict(consolidate_address([p.address for p in per_source if p and p.address])),
		"price": consolidate([p.price for p in per_source]),
		"bedrooms": consolidate([p.bedrooms for p in per_source]),
		"bathrooms": consolidate([p.bathrooms for p in per_source]),
		"sqft": consolidate([p.sqft for p in per_source]),
		"lot_size": consolidate([p.lot_size for p in per_source]),
		"year_built": consolidate([p.year_built for p in per_source]),
		"property_type": consolidate([p.property_type for p in per_source]),
		"last_sold_date": consolidate([p.last_sold_date for p in per_source]),
		"last_sold_price": consolidate([p.last_sold_price for p in per_source]),
	}

	verification = verify_against_input(
		Address(
			street=consolidated["address"].get("street"),
			city=consolidated["address"].get("city"),
			state=consolidated["address"].get("state"),
			postal_code=consolidated["address"].get("postal_code"),
		),
		address_line,
		city,
		state_zip,
	)

	result = {
		"input": {
			"address_line": address_line,
			"city": city,
			"state_zip": state_zip,
		},
		"verification": verification,
		"consolidated": consolidated,
		"sources": [asdict(p) for p in per_source],
	}

	json_path = os.path.join(output_dir, "result.json")
	with open(json_path, "w", encoding="utf-8") as f:
		json.dump(result, f, indent=2, ensure_ascii=False)

	text_lines: List[str] = []
	text_lines.append("Verified Property Summary")
	text_lines.append("")
	text_lines.append(f"Input: {address_line}, {city}, {state_zip}")
	text_lines.append(f"Match Score: {verification['address_match']['score']} (strong={verification['address_match']['is_strong_match']})")
	text_lines.append("")
	text_lines.append("Consolidated:")
	for k, v in consolidated.items():
		if isinstance(v, dict):
			text_lines.append(f"  {k}:")
			for kk, vv in v.items():
				text_lines.append(f"    {kk}: {vv}")
		else:
			text_lines.append(f"  {k}: {v}")
	text_lines.append("")
	text_lines.append("Sources:")
	for p in per_source:
		text_lines.append(f"- {p.source}: {p.source_url}")
	text_path = os.path.join(output_dir, "result.txt")
	with open(text_path, "w", encoding="utf-8") as f:
		f.write("\n".join(text_lines))

	return result


if __name__ == "__main__":
	# Example run for the provided property
	address_line = "8800 S Grizzly Way"
	city = "Evergreen"
	state_zip = "CO 80439"
	res = run_property_agent(address_line, city, state_zip)
	print(json.dumps(res, indent=2)) 