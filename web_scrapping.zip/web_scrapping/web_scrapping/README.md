# Property Verification Agent

This agent searches multiple public real estate websites for a property address, extracts details (address, price, beds, baths, sqft, year built, etc.), verifies the address match, and consolidates results across sources.

## Supported sources
- Zillow
- Redfin
- Realtor
- Trulia
- Movoto
- RE/MAX
- Homesnap

## Setup

1. Create and activate a virtual environment (optional but recommended).
2. Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

Run the agent with the provided address (example uses your input):

```bash
python agent.py
```

Or import and call from Python:

```python
from agent import run_property_agent

result = run_property_agent(
    address_line="8800 S Grizzly Way",
    city="Evergreen",
    state_zip="CO 80439",
)
print(result)
```

Outputs are saved under `output/`:
- `result.json` — structured, consolidated JSON including per-source data
- `result.txt` — human-readable summary and source links

## Notes
- Uses DuckDuckGo to find the most relevant property page on each site.
- Parses JSON-LD when available, with text fallbacks for robustness.
- Adds a small delay between requests; avoid aggressive parallel runs. 