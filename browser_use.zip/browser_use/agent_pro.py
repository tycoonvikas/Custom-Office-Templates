import asyncio
from dotenv import load_dotenv
from browser_use import Agent, ChatGoogle
import os

# Load environment variables from the .env file
load_dotenv()

async def find_repo_stars_with_gemini_2_5_pro():
    """
    Automates a browser to find the number of stars of the browser-use repo
    using the Google Gemini 2.5 Pro model.
    """
    # Create an instance of the ChatGoogle language model with the
    # specific model name "gemini-2.5-pro".
    # The library will automatically use the GOOGLE_API_KEY from the environment.
    llm = ChatGoogle(model="gemini-2.5-pro")

    # Create an Agent instance with the task and the configured language model.
    agent = Agent(
        task="Find the number of stars of the browser-use repo",
        llm=llm,
    )
    print("Starting the browser automation task using the Gemini 2.5 Pro model...")
    await agent.run()
    print("Task completed.")

async def scrape_zillow_property_data():
    """
    Automates a browser to scrape detailed real estate information from a Zillow property page.
    """
    # Use the appropriate LLM class based on your API key
    llm = ChatGoogle(model="gemini-2.5-flash")

    # Define the specific task for the AI agent
    agent = Agent(
        task="""
        Your task is to visit the Zillow property page for the address 2615 East Ave, Rochester, NY 14610.
        Once on the page, you must carefully scrape the following important property features:

        1.  **Price:** The current listed price of the property.
        2.  **Property Type:** Is it a Single Family, Condo, etc.?
        3.  **Bedrooms and Bathrooms:** The total number of beds and baths.
        4.  **Square Footage:** The total finished living area in square feet.
        5.  **Lot Size:** The size of the property lot.
        6.  **Year Built:** The year the property was originally constructed.
        7.  **Key Features/Highlights:** A bulleted list of the most important features mentioned, such as "newly built," "garage," "second kitchen," "materials," etc.
        8.  **Zestimate®:** The estimated value of the home according to Zillow.

        Format all the collected information into a clear, concise, and structured output.
        Begin by searching for the address on Zillow's homepage.
        """,
        llm=llm,
    )

    print("Starting the Zillow scraping task with the AI agent...")
    await agent.run()
    print("Scraping task completed.")

if __name__ == "__main__":
    # Run the main asynchronous function
    asyncio.run(scrape_zillow_property_data())
    #asyncio.run(find_repo_stars_with_gemini_2_5_pro())