import asyncio
from dotenv import load_dotenv
from browser_use import Agent, ChatGoogle
import os

# Load environment variables from the .env file
load_dotenv()

async def find_repo_stars_with_gemini():
    """
    Automates a browser to find the number of stars of the browser-use repo
    using the Google Gemini model.
    """
    # Create an instance of the ChatGoogle language model.
    # It automatically uses the GOOGLE_API_KEY from the environment.
    llm = ChatGoogle(model="gemini-2.5-pro-latest")

    # Create an Agent instance with the task and the configured language model.
    agent = Agent(
        task="Find the number of stars of the browser-use repo",
        llm=llm,
    )
    print("Starting the browser automation task using the Gemini model...")
    await agent.run()
    print("Task completed.")

if __name__ == "__main__":
    # Run the main asynchronous function
    asyncio.run(find_repo_stars_with_gemini())